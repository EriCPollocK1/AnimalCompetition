package Animals.wildAnimal;
import Animals.Animal;

public class bear{
}