import Animals.*;
import Animals.wildAnimal.*;
import Animals.supernaturalAnimal.*;
import gridStuff.*;

public class Main {


    public static void main(String[] args) {
        Legend.drawLegend();
        System.out.println();
        Grid.drawGrid();
    }

}
