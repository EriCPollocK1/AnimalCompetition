package gridStuff;
import Animals.Animal;

public class Legend {
    public static void drawLegend(Animal player1, Animal player2) {
        String playerOne = String.valueOf(player1.getSpecies().charAt(0)) + " = " + player1.getSpecies();
        String playerTwo = String.valueOf(player2.getSpecies().charAt(0)) + " = " + player2.getSpecies();
        String legend[] = {"w = wall", "R = ramp", playerOne, playerTwo};   
        for(int i = 0; i < legend.length; i ++) {
            System.out.println(legend[i]);
        }
    }
}