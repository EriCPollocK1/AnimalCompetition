// Part 3
import Animals.*;
import Animals.supernaturalAnimal.*;
import Animals.wildAnimal.*;
import gridStuff.*;
import java.util.Scanner;
public class Main {
    public static Animal player1;
    public static Animal player2;
    // method used to print out the animal options that you can pick from
    public static void openMenus(String name) {
        if (name.equals("Animal Selection")) {
            System.out.println("Please select an animal");
            System.out.println();
            System.out.print("wolf" + "\n" + "bear" + "\n" + "basalisk" + "\n" + "zeppicorn" + "\n");
        }
    }

    // method to determine the start letter of the players species
    public static String determineLetter(Animal player) {
        if(player == null) return "FAILED";

        String spec = player.getSpecies();
        return String.valueOf(spec.charAt(0));
    }

    // method that will make an object of the player
    public static Animal makeObject(String chose) {

        if(chose.equals("wolf")) {
            return new wolf("wolf", 10);
        }
        else if (chose.equals("bear")) {
            return new bear("bear", 15);
        }
        else if (chose.equals("basalisk")) {
            return new basalisk("basalisk", 25);
        }
        else if (chose.equals("zeppicorn")) {
            return new zeppicorn("zeppicorn", 30);
        } else {
            System.out.println("FAILED");
            return null;
        }
    }


    // method that calls the attack methods for the player inputed
    public static void attack(String line, String person, Animal player1, Animal player2) {
        if(line.equals("bite")) {
            if(person.equals("player1")) {
                player1.bite("player2", "bite", player1, player2);
            }
            else {
                player2.bite("player1", "bite", player1, player2);
            }
        }
        else if (line.equals("swipe")) {
            if(person.equals("player1")) {
                player1.swipe("player2", "swipe", player1, player2);
            }
            else {
                player2.swipe("player1", "swipe", player1, player2);
            }
        }
        else if (line.equals("lunge")) {
            if(person.equals("player1")) {
                player1.lunge("player2", "lunge", player1, player2);
            }
            else {
                player2.lunge("player1", "lunge", player1, player2);
            }
        }
        else if (line.equals("hornjab")) {
            if(person.equals("player1")) {
                player1.hornjab("player2", "hornjab", player1, player2);
            }
            else {
                player2.hornjab("player1", "hornjab", player1, player2);
            }
        }
        else if (line.equals("charge")) {
            if(person.equals("player1")) {
                player1.charge("player2", "charge", player1, player2);
            }
            else {
                player2.charge("player1", "charge", player1, player2);
            }
        }
        else if (line.equals("tailwhip")) {
            if(person.equals("player1")) {
                player1.tailwhip("player2", "tailwhip", player1, player2);
            }
            else {
                player2.tailwhip("player1", "tailwhip", player1, player2);
            }
        }
        else if (line.equals("spitball")) {
            if(person.equals("player1")) {
                player1.spitball("player2", "spitball", player1, player2);
            }
            else {
                player2.spitball("player1", "spitball", player1, player2);
            }
        }
    }

    public static void main(String[] args) {
        String grid[][] = {
            {"0", "1", "2", "3", "4", "5", "6"},
            {"-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-"}
        };
        // set up the scanner
        Scanner scan = new Scanner(System.in);

        // print the animal options
        openMenus("Animal Selection");

        System.out.println("please select the legend you want to use");
        // get input
        String chosen = scan.nextLine();
        // check for correct animal input
        boolean dog = chosen.equals("wolf");
        boolean grizzly = chosen.equals("bear");
        boolean snake = chosen.equals("basalisk");
        boolean freak = chosen.equals("zeppicorn");
        while(dog == false && grizzly == false && snake == false && freak == false) {
            System.out.println("incorrect input");
            chosen = scan.nextLine();
            dog = chosen.equals("wolf");
            grizzly = chosen.equals("bear");
            snake = chosen.equals("basalisk");
            freak = chosen.equals("zeppicorn");
        }
        // ask to see if they do actually want that legend
        System.out.println("You have selected the Animal legend " + chosen + " Would you like to begin with this legend?");
        String line = scan.nextLine();
        // if they say no allow them to pick another legend
        while(line.equals("no") || line.equals("No")) {
            System.out.println("please select the legend you want to use");
            line = scan.nextLine();

            dog = chosen.equals("wolf");
            grizzly = chosen.equals("bear");
            snake = chosen.equals("basalisk");
            freak = chosen.equals("zeppicorn");
            while(dog == false && grizzly == false && snake == false && freak == false) {
                System.out.println("incorrect input");
                chosen = scan.nextLine();
                dog = chosen.equals("wolf");
                grizzly = chosen.equals("bear");
                snake = chosen.equals("basalisk");
                freak = chosen.equals("zeppicorn");
            }   
        }
        // make an object for the first player
        player1 = makeObject(chosen);

        // get player 2 to select their legend
        System.out.println("Player 1 has chosen their Animal legend. Player 2, please choose your legend.");
        openMenus("Animal Selection");
        System.out.println();
        chosen = scan.nextLine();
        // check for the correct animal input
        dog = chosen.equals("wolf");
        grizzly = chosen.equals("bear");
        snake = chosen.equals("basalisk");
        freak = chosen.equals("zeppicorn");
        while(dog == false && grizzly == false && snake == false && freak == false) {
            System.out.println("incorrect input");
            chosen = scan.nextLine();
            dog = chosen.equals("wolf");
            grizzly = chosen.equals("bear");
            snake = chosen.equals("basalisk");
            freak = chosen.equals("zeppicorn");
        }   

        System.out.println("You have selected the Animal legend " + chosen + ", are you sure this is the legend you want?");
        line = scan.nextLine();
        // if player 2 wants a different legend than what they chose, regive them the options and get their new imput
        while(line.equals("no") || line.equals("No")) {
            System.out.println("please select the legend you want to use");
            line = scan.nextLine();

            dog = chosen.equals("wolf");
            grizzly = chosen.equals("bear");
            snake = chosen.equals("basalisk");
            freak = chosen.equals("zeppicorn");
            while(dog == false && grizzly == false && snake == false && freak == false) {
                System.out.println("incorrect input");
                chosen = scan.nextLine();
                dog = chosen.equals("wolf");
                grizzly = chosen.equals("near");
                snake = chosen.equals("basalisk");
                freak = chosen.equals("zeppicorn");
            }   
            // if not ask for another input, if correct input verify that the player would like this as their legend
            System.out.println("You have selected the Animal legend " + chosen + " Would you like to begin with this legend?");
            line = scan.nextLine();
        }

        // make the object of player 2
        player2 = makeObject(chosen);

        System.out.println("Both Players have selected their legends say start when you are ready to begin");
        line = scan.nextLine();

        // set the letters the players will be represented with on the board
        String startLetter1 = determineLetter(player1);
        String startLetter2 = determineLetter(player2);



        // check to see if they have started the game
        if(line.equals("start") || line.equals("Start")) {
            //draw out the grid
            Grid.drawGrid(grid, player1, player2, 0);

            // this runs the turns, it will repeat untill one person dies
            while(player1.getHealth() > 0 && player2.getHealth() > 0) {
                Legend.drawLegend(player1, player2);
                Grid.drawGrid(grid, player1, player2, 1);
                System.out.println("Player one's turn");

                // find player1's location on the grid and show possible moves
                Grid.moves(grid, Grid.searchGridRow(grid, startLetter1), Grid.searchGridColounm(grid, startLetter1), player1, player2, "player1", "player2");
                // get the players action input
                System.out.println("Please select your input");
                line = scan.nextLine();
                // if they are moving run this part
                if(line.equals("up") || line.equals("upLeft") || line.equals("upRight") || line.equals("left") || line.equals("right") || line.equals("down") || line.equals("downRight") || line.equals("downLeft")) {
                    Grid.moveGrid(grid, line, "player1", Grid.searchGridRow(grid, determineLetter(player1)), Grid.searchGridColounm(grid, determineLetter(player1)), player1, player2);
                }
                // this will run their attacks
                else {
                    attack(line, "player1", player1, player2);
                }
                //show players health
                System.out.println("player1's health " + player1.getHealth() + " player2's health " + player2.getHealth());
                //print the grid again
                Grid.drawGrid(grid, player1, player2, 1);
                System.out.println("Player 1 has made their move, Player two's turn");
                
                // find player2's location on the grid and show possible moves
                Grid.moves(grid, Grid.searchGridRow(grid, startLetter2), Grid.searchGridColounm(grid, startLetter2), player1, player2, "player2", "player1");
                // get player 2's action input
                System.out.println("Please select an input");
                line = scan.nextLine();
                //implement the input                   
                if(line.equals("up") || line.equals("upLeft") || line.equals("upRight") || line.equals("left") || line.equals("right") || line.equals("down") || line.equals("downRight") || line.equals("downLeft")) {
                    Grid.moveGrid(grid, line, "player2", Grid.searchGridRow(grid, determineLetter(player2)), Grid.searchGridColounm(grid, determineLetter(player2)), player1, player2);
                }
                else {
                    attack(line, "player2", player1, player2);
                }
                //show players health
                System.out.println("player1's health " + player1.getHealth() + " player2's health " + player2.getHealth());
            }
            if(player1.getHealth() > 0) {
                System.out.println("congratulations player1 has defeated player2 and one the animal competition");
            } else {
                System.out.println("congratulations player2 has defeated player1 and one the animal competition");
            }
        }
    }
}
