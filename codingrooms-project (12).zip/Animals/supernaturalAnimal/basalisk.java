package Animals.supernaturalAnimal;
import Animals.Animal;

public class basalisk extends supernaturalAnimal {
    
    public basalisk(String _species, int _health) {
        super(_species, _health);
    }

    // spitball attack
    public void spitball(String enemy, String attack, Animal player1, Animal player2) {
        if(enemy.equals("player1")) {
            player1.changeHealth(attack);
        }
        else {
            player2.changeHealth(attack);
        }
    }
    // tailwhip attack
    public void tailWhip(String enemy, String attack, Animal player1, Animal player2) {
        if(enemy.equals("player1")) {
            player1.changeHealth(attack);
        }
        else {
            player2.changeHealth(attack);
        }
    }

    public void changeHealth(String attack) {
        super.changeHealth(attack);
    }
}