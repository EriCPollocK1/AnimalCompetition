package Animals.supernaturalAnimal;
import Animals.Animal;

public class zeppicorn extends supernaturalAnimal{

    public zeppicorn(String _species, int _health) {
        super(_species, _health);
    }
    // hornjab attack
    public void hornJab(String enemy, String attack, Animal player1, Animal player2) {
        if(enemy.equals("player1")) {
            player1.changeHealth(attack);
        }
        else {
            player2.changeHealth(attack);
        }
    }
    // charge attack
    public void charge(String enemy, String attack, Animal player1, Animal player2) {
        if(enemy.equals("player1")) {
            player1.changeHealth(attack);
        }
        else {
            player2.changeHealth(attack);
        }
    }

    public void changeHealth(String attack) {
        super.changeHealth(attack);
    }
}