package gridStuff;

import Animals.Animal;

public class Grid {
    // this method will draw out the grid for whenever is needed, called throughout the game
    public static void drawGrid(String [][] grid, Animal player1, Animal player2, int counter) {
       // put the players character into the grid for the start of the game
        if (counter == 0) {
            String playerLetter1 = String.valueOf(player1.getSpecies().charAt(0));
            String playerLetter2 = String.valueOf(player2.getSpecies().charAt(0));
            grid[1][3] = playerLetter1;
            grid[5][3] = playerLetter2;
        }
        // loop through the grid and print it out
        for(int i = 0; i < 7; i ++) {
            for(int j = 0; j < 7; j ++) {
                System.out.print(grid[i][j]);
                System.out.print(" ");
            }
            System.out.println();
        }
    }

    // method to find the row position of the player
    public static int searchGridRow(String[][] grid, String searchLetter) { 
        int rowLoc = 0;
            for(int i = 0; i < 7; i ++) {
                for(int j = 0; j < 7; j ++) {
                    if(grid[i][j].equals(searchLetter)) {
                        rowLoc = i;
                    }
                }
            }
        return rowLoc;
    }    
     // method to find the colounm position of the player
    public static int searchGridColounm(String[][] grid, String searchLetter) { 
    int colounmLoc = 0;
        for(int i = 0; i < 7; i ++) {
            for(int j = 0; j < 7; j ++) {
                if(grid[i][j].equals(searchLetter)) {
                    colounmLoc = j;
                }
            }
        }
        return colounmLoc;
    }    
    // method shows the available moves to the player
    public static void moves(String[][] grid, int row, int colounm, Animal player1, Animal player2, String player, String enemy) {
        // get the first letter of the player's legend
        String startLetter = "";
        if (enemy.equals("player1")) {
            startLetter = String.valueOf(player1.getSpecies().charAt(0));
        }
        else {
            startLetter = String.valueOf(player2.getSpecies().charAt(0));
        }
        String[] spots = new String[8]; 
        String upLeft = "";
        String up = "";
        String upRight = "";
        String left = "";
        String right = "";
        String downLeft = "";
        String down = "";
        String downRight = "";
        // set the variables that will be used to check what is around the player
        if(row >= 2 && colounm >= 1) {
            upLeft = grid[row - 1][colounm - 1];
            up = grid[row - 1][colounm];
            upRight = grid[row - 1][colounm + 1];
            right = grid[row][colounm + 1];
            left = grid[row][colounm - 1];
            downLeft = grid[row + 1][colounm - 1];
            down = grid[row + 1][colounm];
            downRight = grid[row + 1][colounm + 1];
        }
        else if (row == 1 && colounm == 0) {
            right = grid[row][colounm + 1];
            downRight = grid[row + 1][colounm + 1];
            down = grid[row + 1][colounm];
        }
        else if (row == 1) {
            downLeft = grid[row + 1][colounm - 1];
            down = grid[row + 1][colounm];
            downRight = grid[row + 1][colounm + 1];
            right = grid[row][colounm + 1];
            left = grid[row][colounm - 1];
        }
        else {
            up = grid[row - 1][colounm];
            upRight = grid[row - 1][colounm + 1];
            right = grid[row][colounm + 1];
            down = grid[row + 1][colounm];
            downRight = grid[row + 1][colounm + 1];
        }
        spots = new String[]{up, upLeft, upRight, right, left, downLeft, downRight, down};
        String[] names = new String[] {"up", "upLeft", "upRight", "right", "left", "downLeft", "downRight", "down"};
        // see if there is a blank spot so you can see if they can move to that block
        String[] move = new String [10];
        for(int a = 0; a < spots.length; a ++) {
            // move
            if (spots[a].equals("-")) {
                int holder = 0;
                int counter = 0;
                for(int b = 0; b < 8; b ++) {
                    if(move[b] == null && counter == 0){
                        holder = b;
                        counter ++;
                    }
                }
                move[holder] = names[a];
            }
            // when the other player is in range tell them what attacks they can use according to their chosen animal
            else if (spots[a].equals(startLetter)) {
                if(player.equals("player1")) {
                    if(player1.getSpecies().equals("wolf")) {
                        move[7] = "bite";
                        move[8] = "lunge";
                    }
                    else if (player1.getSpecies().equals("bear")) {
                        move[7] = "bite";
                        move[8] = "swipe";
                    }
                    else if (player1.getSpecies().equals("basalisk")) {
                        move[7] = "tailwhip";
                        move[8] = "spitball";
                    }
                    else {
                        move[7] = "hornjab";
                        move[8] = "charge";
                    }
                }
                else {
                    if(player2.getSpecies().equals("wolf")) {
                        move[7] = "bite";
                        move[8] = "lunge";
                    }
                    else if (player2.getSpecies().equals("bear")) {
                        move[7] = "bite";
                        move[8] = "swipe";
                    }
                    else if (player2.getSpecies().equals("basalisk")) {
                        move[7] = "tailwhip";
                        move[8] = "spitball";
                    }
                    else {
                        move[7] = "hornjab";
                        move[8] = "charge";
                    }
                }
            }
        }
        // print out available moves for the player
        for(int f = 0; f < move.length; f ++) {
            System.out.println(move[f]);
        }
    }    
    // this method will take the players name and their action that they have selected
    // it will move the player from it's original position to the new selected spot
    public static void moveGrid(String[][] grid, String input, String player, int row, int colounm, Animal player1, Animal player2) {
        // find the players start letter of animal
        String letter = "";
        if(player.equals("player1")) {
            letter = String.valueOf(player1.getSpecies().charAt(0));
        }
        else {
            letter = String.valueOf(player2.getSpecies().charAt(0));
        }
        if(input.equals("down")) {
            grid[row][colounm] = "-";
            grid[row + 1][colounm] = letter;
        }
        else if (input.equals("downLeft")) {
            grid[row][colounm] = "-";
            grid[row + 1][colounm - 1] = letter;
        }
        else if (input.equals("downRight")) {
            grid[row][colounm] = "-";
            grid[row + 1][colounm + 1] = letter;
        }
        else if (input.equals("right")){
            grid[row][colounm] = "-";
            grid[row][colounm + 1] = letter;
        }
        else if (input.equals("left")) {
            grid[row][colounm] = "-";
            grid[row][colounm - 1] = letter;
        }   
        else if (input.equals("up")) {
            grid[row][colounm] = "-";
            grid[row - 1][colounm] = letter;
        }   
        else if (input.equals("upLeft")) {
            grid[row][colounm] = "-";
            grid[row - 1][colounm - 1] = letter;
        }  
        else if (input.equals("upRight")) {
            grid[row][colounm] = "-";
            grid[row - 1][colounm + 1] = letter;
        }
    }
}