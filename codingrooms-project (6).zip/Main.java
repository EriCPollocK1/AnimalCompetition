// Part 3
import Animals.*;
import Animals.supernaturalAnimal.*;
import Animals.wildAnimal.*;
import gridStuff.*;
import Menu.*;
import java.util.Scanner;
public class Main {
    Scanner scan = new Scanner(System.in);

    // public static void openMenus(name) {
    //     if(name.equals(Menu)) {
    //     }
    //     else if (name.equals(Character Selection)) {
    //     }
    //     else if (name.equals(Rules)) {
    //     }
    // }


    public static void main(String[] args) {
        // menu.drawMenu();
        // input.getInput();

        Grid.drawGrid();
        System.out.println();
        Legend.drawLegend();
    }

}
