package Animals.wildAnimal;
import Animals.Animal;

public class wolf {
}