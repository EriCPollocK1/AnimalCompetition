package Animals;
public abstract class Animal {
}