package Menu;

public class menu {
    public static void drawMenu() {
          System.out.print("Menu" + "\n" + "\n" + "Character Selection" + "\n" + "\n" + "Rules" + "\n");
    }
}