package gridStuff;

public class Legend {
    public static void drawLegend() {
    String legend[] = {"w = wall", "R = ramp"};   
    for(int i = 0; i < legend.length; i ++) {
        System.out.println(legend[i]);
    }
    }
}