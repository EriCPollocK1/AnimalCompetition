package gridStuff;

public class Grid {
    public static void drawGrid() {
        String grid[][] = {
            {" ", "1", "2", "3", "4"},
            {"A", "-", "-", "-", "-"},
            {"B", "r", "-", "-", "-"},
            {"C", "-", "-", "w", "-"},
            {"D", "w", "-", "-", "-"},
            {"E", "-", "-", "-", "-"},
        };
        for(int i = 0; i < 6; i ++) {
            for(int j = 0; j < 5; j ++) {
                System.out.print(grid[i][j]);
                System.out.print(" ");
            }
            System.out.println();
        }
    }
}