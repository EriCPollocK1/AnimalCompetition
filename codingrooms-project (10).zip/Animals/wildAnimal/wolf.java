package Animals.wildAnimal;
import Animals.Animal;

public class wolf extends wildAnimal{

    public wolf(String _species, int _health) {
        super(_species, _health);
    }

    public void lunge(String enemy, String attack, Animal player1, Animal player2) {
        if(enemy.equals("player1")) {
            player1.changeHealth(attack);
        }
        else {
            player2.changeHealth(attack);
        }
    }

    public void changeHealth(String attack) {
        super.changeHealth(attack);
    }    

    public void bite(String enemy, String attack, Animal player1, Animal player2) {
        super.bite(enemy, attack, player1, player2);
    }
}