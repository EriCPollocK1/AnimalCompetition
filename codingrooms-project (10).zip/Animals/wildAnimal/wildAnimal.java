package Animals.wildAnimal;
import Animals.Animal;

public class wildAnimal extends Animal {
    // bite attack
    public wildAnimal(String _species, int _health) {
        super(_species, _health);
    }

    public void changeHealth(String attack) {
        super.changeHealth(attack);
    }

    public void bite(String enemy, String attack, Animal player1, Animal player2) {
if(enemy.equals("player1")) {
            player1.changeHealth(attack);
        }
        else {
            player2.changeHealth(attack);
        }    }
}