package Animals;
public abstract class Animal {

    protected String species;
    protected int health;

    public Animal(String _species, int _health) {
        species = _species;
        health = _health;
    }
    
    public void changeHealth(String attack) {
        if(attack.equals("charge")) {
            health = health - 8;
        }
        else if (attack.equals("bite")) {
            health = health - 3;
        }
        else if (attack.equals("swipe")) {
            health = health - 5;
        }
        else if (attack.equals("hornjab")) {
            health = health - 7;
        }
        else if (attack.equals("tailwhip")) {
            health = health - 10;
        }
        else if (attack.equals("spitball")) {
            health = health - 9;
        }
    }

    public int getHealth() {
        return this.health;
    }

    public String getSpecies() {
        return this.species;
    }
}