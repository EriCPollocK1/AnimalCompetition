package gridStuff;

import Animals.Animal;

public class Grid {
    // this method will draw out the grid for whenever is needed, called throughout the game
    public static void drawGrid(String [][] grid, Animal player1, Animal player2, int counter) {
       // put the players character into the grid for the start of the game
        if (counter == 0) {
            String playerLetter1 = String.valueOf(player1.getSpecies().charAt(0));
            String playerLetter2 = String.valueOf(player2.getSpecies().charAt(0));
            grid[3][2] = playerLetter1;
            grid[3][5] = playerLetter2;
        }
        for(int i = 0; i < 6; i ++) {
            for(int j = 0; j < 5; j ++) {
                System.out.print(grid[i][j]);
                System.out.print(" ");
            }
            System.out.println();
        }
    }

    // method to find the row position of the player
    public static int searchGridRow(String[][] grid, String searchLetter) { 
        int rowLoc = 0;
        for(int i = 0; i < 5; i ++) {
            for(int j = 0; j < 5; j ++) {
                if(grid[i][j] == searchLetter) {
                    rowLoc = i;
                }
            }
        }
        return rowLoc;
    }    
     // method to find the colounm position of the player
    public static int searchGridColounm(String[][] grid, String searchLetter) { 
    int colounmLoc = 0;
        for(int i = 0; i < 5; i ++) {
            for(int j = 0; j < 5; j ++) {
                if(grid[i][j] == searchLetter) {
                    colounmLoc = j;
                }
            }
        }
        return colounmLoc;
    }    
    // method shows the available moves to the player
    public static void moves(String[][] grid, int row, int colounm, Animal player1, Animal player2, String player) {
        String startLetter = "";
        if (player.equals("player1")) {
            startLetter = String.valueOf(player1.getSpecies().charAt(0));
        }
        else {
            startLetter = String.valueOf(player2.getSpecies().charAt(0));
        }
        // check i + 1, j + 1, j - 1
        // check j + 1, j - 1
        // check i - 1, j + 1, j - 1
        String[] spots = new String[8]; 
        String upLeft = "";
        String up = "";
        String upRight = "";
        String left = "";
        String right = "";
        String downLeft = "";
        String down = "";
        String downRight = "";
        if(row >= 1 && colounm >= 1) {
            upLeft = grid[row - 1][colounm - 1];
            up = grid[row - 1][colounm];
            upRight = grid[row - 1][colounm + 1];
            right = grid[row][colounm + 1];
            left = grid[row][colounm - 1];
            downLeft = grid[row + 1][colounm - 1];
            down = grid[row + 1][colounm];
            downRight = grid[row + 1][colounm + 1];
        }
        else if (row == 0 && colounm == 0) {
            up = grid[row - 1][colounm];
            upRight = grid[row - 1][colounm + 1];
            right = grid[row][colounm + 1];
        }
        else if (row == 0) {
            upLeft = grid[row - 1][colounm - 1];
            up = grid[row - 1][colounm];
            upRight = grid[row - 1][colounm + 1];
            right = grid[row][colounm + 1];
            left = grid[row][colounm - 1];
        }
        else {
            up = grid[row - 1][colounm];
            upRight = grid[row - 1][colounm + 1];
            right = grid[row][colounm + 1];
            down = grid[row + 1][colounm];
            downRight = grid[row + 1][colounm + 1];
        }
        spots = new String[]{up, upLeft, upRight, right, left, downLeft, downRight, down};
        for (int t = 0; t < spots.length; t ++) {
            System.out.println(spots[t]);
        }

        // printing and checking the moves
        String[] move = new String [10];
        for(int a = 0; a < spots.length; a ++) {
            // move
            if(spots[a] == "-") {
                for(int b = 0; b < 8; b ++) {
                    if(move[b] == null) {
                        move[b] = spots[a];
                    }
                }
            }
            else if (spots[a] == startLetter) {
                for(int b = 0; b < 8; b ++) {
                    if(move[b] == null) {
                        if(player.equals("player1")) {
                            if(player1.getSpecies().equals("wolf")) {
                                move[b] = "bite";
                                move[b ++] = "lunge";
                            }
                            else if (player1.getSpecies().equals("bear")) {
                                move[b] = "bite";
                                move[b ++] = "swipe";
                            }
                            else if (player1.getSpecies().equals("basalisk")) {
                                move[b] = "tailwhip";
                                move[b ++] = "spitball";
                            }
                            else {
                                move[b] = "hornjab";
                                move[b ++] = "charge";
                            }
                        }
                        else {
                            if(player2.getSpecies().equals("wolf")) {
                                move[b] = "bite";
                                move[b ++] = "lunge";
                            }
                            else if (player2.getSpecies().equals("bear")) {
                                move[b] = "bite";
                                move[b ++] = "swipe";
                            }
                            else if (player2.getSpecies().equals("basalisk")) {
                                move[b] = "tailwhip";
                                move[b ++] = "spitball";
                            }
                            else {
                                move[b] = "hornjab";
                                move[b ++] = "charge";
                            }
                        }
                    }
                }
            }
        }
        }    
        // this method will take the players name and their action that they have selected
        // it will move the player from it's original position to the new selected spot
        public static void moveGrid(String[][] grid, String input, String player, int row, int colounm, Animal player1, Animal player2) {
            String letter = "";
            if(player.equals("player1")) {
                letter = String.valueOf(player1.getSpecies().charAt(0));
            }
            else {
                letter = String.valueOf(player2.getSpecies().charAt(0));
            }
            if(input.equals("down")) {
                grid[row][colounm] = "-";
                grid[row ++][colounm] = letter;
            }
            else if (input.equals("downLeft")) {
                grid[row][colounm] = "-";
                grid[row ++][colounm --] = letter;
            }
            else if (input.equals("downRight")) {
                grid[row][colounm] = "-";
                grid[row ++][colounm ++] = letter;
            }
            else if (input.equals("right")){
                grid[row][colounm] = "-";
                grid[row][colounm ++] = letter;
            }
            else if (input.equals("left")) {
                grid[row][colounm] = "-";
                grid[row --][colounm] = letter;
            }   
            else if (input.equals("up")) {
                grid[row][colounm] = "-";
                grid[row][colounm --] = letter;
            }   
            else if (input.equals("upLeft")) {
                grid[row][colounm] = "-";
                grid[row --][colounm --] = letter;
            }  
            else if (input.equals("upRight")) {
                grid[row][colounm] = "-";
                grid[row --][colounm ++] = letter;
            }
        }

        // if they choose to attack this
        public static void attack() {

        }
    }