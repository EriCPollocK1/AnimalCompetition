package Menu;

public class characterSelection {
    public static void drawCharacterOptions() {
    }
}