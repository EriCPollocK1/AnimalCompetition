package Animals.supernaturalAnimal;
import Animals.Animal;

public class basalisk extends supernaturalAnimal {
    
    public basalisk(String _species, int _health) {
        super(_species, _health);
    }


    public void spitball() {

    }

    public void tailWhip() {

    }


}