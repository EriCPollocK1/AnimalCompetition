package Animals.supernaturalAnimal;
import Animals.Animal;

public class supernaturalAnimal extends Animal{
    public supernaturalAnimal(String _species, int _health) {
        super(_species, _health);
    }
}