package Animals.supernaturalAnimal;
import Animals.Animal;

public class zeppicorn extends supernaturalAnimal{

    public zeppicorn(String _species, int _health) {
        super(_species, _health);
    }

    public void hornJab() {

    }

    public void charge() {

    }

    
}