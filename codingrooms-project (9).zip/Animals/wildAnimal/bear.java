package Animals.wildAnimal;
import Animals.Animal;

public class bear extends wildAnimal {

    public bear(String _species, int _health) {
        super(_species, _health);
    }

    public void swipe() {

    }

}