package Menu;

public class rules {
    public static void drawRules() {
        
    }
}