package Menu;

public class menu {
    public static void drawMenu() {
          System.out.print("Menu" + "\n" + "\n" + "Animal Selection" + "\n" + "\n" + "Rules" + "\n");
    }
}