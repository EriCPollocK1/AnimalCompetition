package gridStuff;

public class Grid {
    public static void drawGrid() {
        String grid[][] = {
            {" ", "1", "2", "3", "4"},
            {"A", "-", "-", "-", "-"},
            {"B", "r", "-", "-", "-"},
            {"C", "-", "-", "w", "-"},
            {"D", "w", "-", "-", "-"},
            {"E", "-", "-", "-", "-"},
        };
        for(int i = 0; i < 6; i ++) {
            for(int j = 0; j < 5; j ++) {
                System.out.print(grid[i][j]);
                System.out.print(" ");
            }
            System.out.println();
        }
    }
    // method to find where the player is positioned on the grid
    public static void searchGrid(String[][] grid, String searchLetter) { 
        int rowLoc = 0;
        int colounmLoc = 0;
        for(int i = 0; i < 5; i ++) {
            for(int j = 0; j < 5; j ++) {
                if(grid[i][j] == searchLetter) {
                    colounmLoc = j;
                    rowLoc = i;
                   // System.out.println(rowLocation + "\n" + colounmLocation);
                }
            }
        }

       System.out.println(rowLoc + "\t" + colounmLoc);
       System.out.println();
       System.out.println();
         // check i + 1, j + 1, j - 1
        // check j + 1, j - 1
        // check i - 1, j + 1, j - 1

        String upLeft = grid[rowLoc + 1][colounmLoc - 1];
        String up = grid[rowLoc + 1][colounmLoc];
        String upRight = grid[rowLoc + 1][colounmLoc + 1];
        String right = grid[rowLoc][colounmLoc + 1];
        String left = grid[rowLoc][colounmLoc - 1];
        String downLeft = grid[rowLoc - 1][colounmLoc - 1];
        String down = grid[rowLoc - 1][colounmLoc];
        String downRight = grid[rowLoc - 1][colounmLoc + 1];

        String[] spots = {upLeft, up, upRight, right, left, downLeft, down, downRight};

        // printing and checking the moves
        String[] move = new String [8];
        for(int a = 0; a < spots.length; a ++) {
            // move
            if(spots[a] == " ") {
                for(int b = 0; b < 8; b ++) {
                    if(move[b] == null) {
                    move[b] = spots[a];
                    }
                }
            }
            // attack
            /*
            if(spots[a] == "")
            */
        }

        for(int d = 0; d < move.length; d ++) {
            System.out.println(move[d]);
        }
    }
}