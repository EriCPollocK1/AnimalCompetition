package Attack;
interface bite {
    public void sound();
    public void bite();
}
interface health {
    //changeHealth();
}

// make a method to scan around where the player is and see possible moves

// make a method that will do the bite attack
public class Attack {
}