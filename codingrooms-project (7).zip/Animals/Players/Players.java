package Players;

public class Players {
    
    private String species;
    private String player;
    private int health;

    public Players(String _player, String _species, int _health) {
        this.species = _species;
        this.player = _player;
        this.health = _health;
    }
    public String species() {
        return this.species;
    }

    public int health() {
        return this.health
    }
}