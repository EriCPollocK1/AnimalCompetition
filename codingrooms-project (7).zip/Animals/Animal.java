package Animals;
public abstract class Animal {

    protected String species;
    protected String name;
    protected int health;

    public static void Animal(String _name, String _species, int -health) {
        this.name = _name;
        this.species = _species;
        this.health = _health;
    }
    //get health
    //get species
    public int getHealth() {
        return this.health;
    }

    public String getSpecies() {
        return this.species;
    }
}