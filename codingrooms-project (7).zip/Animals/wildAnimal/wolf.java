package Animals.wildAnimal;
import Animals.Animal;

public class wolf {

    protected String species = "wolf";
    protected String name;
    protected int health = 20;

    public void lunge() {

    }

    
}