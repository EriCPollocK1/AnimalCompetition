package Animals.wildAnimal;
import Animals.Animal;

public class bear{

    protected String species = "bear";
    protected String name;
    protected int health = 40;
    
    public void swipe() {

    }

}