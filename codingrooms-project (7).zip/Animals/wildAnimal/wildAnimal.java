package Animals.wildAnimal;
import Animals.Animal;

public class wildAnimal {
    // bite attack
}