package Animals.supernaturalAnimal;
import Animals.Animal;

public class basalisk {
    
protected int health = 60;
protected String species = "Basalisk";
protected String name = "Greg";



    public void spitball() {

    }

    public void tailWhip() {

    }


}