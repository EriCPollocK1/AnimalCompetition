package Animals.supernaturalAnimal;
import Animals.Animal;

public class zeppicorn {

    protected String species = "zeppicorn";
    protected String name;
    protected int health = 60;

    public void hornJab() {

    }

    public void charge() {

    }

    
}