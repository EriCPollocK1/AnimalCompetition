package Animals;
public abstract class Animal {

    protected String species;
    protected int health;

    public Animal(String _species, int _health) {
        species = _species;
        health = _health;
    }
    //get health
    //get species
    public int getHealth() {
        return this.health;
    }

    public String getSpecies() {
        return this.species;
    }
}