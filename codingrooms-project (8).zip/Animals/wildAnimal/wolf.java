package Animals.wildAnimal;
import Animals.Animal;

public class wolf extends wildAnimal{

    public wolf(String _species, int _health) {
        super(_species, _health);
    }

    public void lunge() {

    }

    
}