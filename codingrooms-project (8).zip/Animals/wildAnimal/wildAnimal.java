package Animals.wildAnimal;
import Animals.Animal;

public class wildAnimal extends Animal {
    // bite attack
    public wildAnimal(String _species, int _health) {
        super(_species, _health);
    }
}