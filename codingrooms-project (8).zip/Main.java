// Part 3
import Animals.*;
import Animals.supernaturalAnimal.*;
import Animals.wildAnimal.*;
import gridStuff.*;
import Menu.*;
import java.util.Scanner;
public class Main {
static Animal player1;
static Animal player2;
    public static void openMenus(String name) {
        if (name.equals("Animal Selection")) {
            System.out.println("Please select an animal");
            System.out.println();
            System.out.print("Wolf" + "\n" + "Bear" + "\n" + "Basalisk" + "\n" + "Zeppicorn");
        }
        else if (name.equals("Rules")) {
            System.out.print("");
        }
    }

    public static void makeObject(String chose, String name, int n) {
        if(name.equals("player1")) {
            if(chose == "Wolf") {
                wolf player1 = new wolf("Wolf", 10);
            }
            else if (chose == "Bear") {
                bear player1 = new bear("Bear", 15);
            }
            else if (chose == "Basilisk") {
                basalisk player1 = new basalisk("Basilisk", 25);
            }
            else if (chose == "Zeppicorn") {
                zeppicorn player1 = new zeppicorn("Zeppicorn", 30);
            }
        }
        else {
            if(chose == "Wolf") {
            wolf player2 = new wolf("Wolf", 10);
        }
        else if (chose == "Bear") {
            bear player2 = new bear("Bear", 15);
        }
        else if (chose == "Basilisk") {
            basalisk player2 = new basalisk("Basilisk", 25);
        }
        else if (chose == "Zeppicorn") {
            zeppicorn player2 = new zeppicorn("Zeppicorn", 30);
        }
        }
    }


    public static void main(String[] args) {
        // // variables
        String[][] grid = {
            {" ", "1", "2", "3", "4"},
            {"A", "-", "-", "-", "-"},
            {"B", "r", "-", "-", "-"},
            {"C", "-", "-", "w", "-"},
            {"D", "w", "-", "-", "-"},
            {"E", "-", "-", "-", "-"},
        };
        int player1Health = 0;
        int player2Health = 0;
        // set up the scanner
        Scanner scan = new Scanner(System.in);
        // print out the main menu and get the user to select an option
        menu.drawMenu();
        System.out.println("Please select a menu");
        String line = scan.nextLine();
        // check for ligitimate input and ask for another input if incorrect
        boolean character = line.equals("Animal Selection");
        boolean rule = line.equals("Rules");
        while (rule == false && character == false) {
            System.out.println("incorrect input");
            line = scan.nextLine();
        }
        // open menu that the user has selected 
        openMenus(line);

        if(line.equals("Animal Selection")) {
            System.out.println();
        // character selection code
        // scan for the input and check if it is a option to choose from

        System.out.println("please select the legend you want to use");
        String chosen = scan.nextLine();
        boolean dog = chosen.equals("Wolf");
        boolean grizzly = chosen.equals("Bear");
        boolean snake = chosen.equals("Basalisk");
        boolean freak = chosen.equals("Zeppicorn");
            while(dog == false && grizzly == false && snake == false && freak == false) {
                System.out.println("incorrect input");
                chosen = scan.nextLine();
            }

        // if not ask for another input, if correct input verify that the player would like this as their legend
        System.out.println("You have selected the Animal legend " + chosen + " Would you like to begin with this legend?");
        line = scan.nextLine();
        while(line.equals("no") || line.equals("No")) {
            System.out.println("please select the legend you want to use");
            line = scan.nextLine();

            chosen = scan.nextLine();
        dog = chosen.equals("Wolf");
        grizzly = chosen.equals("Bear");
        snake = chosen.equals("Basalisk");
        freak = chosen.equals("Zeppicorn");
        if(line.equals("Animal Selection")) {
            while(dog == false && grizzly == false && snake == false && freak == false) {
                System.out.println("incorrect input");
                chosen = scan.nextLine();
            }
        }
        // if not ask for another input, if correct input verify that the player would like this as their legend
        System.out.println("You have selected the Animal legend " + chosen + " Would you like to begin with this legend?");
        line = scan.nextLine();
        }
        //set the playeres health to the health that their legend has
        // playerUpdate();
        // get player 2 to select their legend
        System.out.println("Player 1 has chosen their Animal legend. Player 2, please choose your legend.");

        makeObject(chosen, "player1", 0);

        openMenus("Animal Selection");
        System.out.println();
        chosen = scan.nextLine();
        dog = chosen.equals("Wolf");
        grizzly = chosen.equals("Bear");
        snake = chosen.equals("Basalisk");
        freak = chosen.equals("Zeppicorn");
            while(dog == false && grizzly == false && snake == false && freak == false) {
                System.out.println("incorrect input");
                chosen = scan.nextLine();
            }
            System.out.println("You have selected the Animal legend " + chosen + ", are you sure this is the legend you want?");
            line = scan.nextLine();
            while(line.equals("no") || line.equals("No")) {
                System.out.println("please select the legend you want to use");
                line = scan.nextLine();

                chosen = scan.nextLine();
                dog = chosen.equals("Wolf");
                grizzly = chosen.equals("Bear");
                snake = chosen.equals("Basalisk");
                freak = chosen.equals("Zeppicorn");
                if(line.equals("Animal Selection")) {
                    while(dog == false && grizzly == false && snake == false && freak == false) {
                        System.out.println("incorrect input");
                        chosen = scan.nextLine();
                    }
                }
            }
            // set the players health the health their legend has
            makeObject(chosen,"player2", 1);

            System.out.println("Both Players have selected their legends say start when you are ready to begin");
            line = scan.nextLine();

            // start the game and print out the map

            if(line.equals("begin") || line.equals("Begin")) {
                Grid.drawGrid();
                Legend.drawLegend();
            }

            // set the letters the players will be represented with on the board
            String startLetter1 = Grid.determineLetter("player1");
            String startLetter2 = Grid.determineLetter("player2");

            // this runs the turns, it will repeat untill one person dies
            while(player1Health > 0 && player2Health > 0) {
                Legend.drawLegend();
                Grid.drawGrid();
                System.out.println("Player one's turn");

                   // find the players location on the grid
                Grid.searchGrid(grid, startLetter1, startLetter2);
                // show all possible moves available

                line = scan.nextLine();

                // move

                //print the grid again
                Grid.drawGrid();
                System.out.println("Player 1 has made their move, Player two's turn");
                // find the player
                Grid.searchGrid(grid, startLetter2, startLetter1);
                // show all moves

                line = scan.nextLine();

                //move and print the grid
            }

}
    }
}
